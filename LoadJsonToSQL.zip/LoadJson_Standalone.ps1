# ============================================================================
#  LoadJson_Standalone.ps1
#  Direct JSON → SQL Server bulk loader — no SSIS required.
#  Uses .NET JsonTextReader + SqlBulkCopy for high-throughput 100M+ row loads.
#
#  USAGE:
#    .\LoadJson_Standalone.ps1 `
#        -SourceFolder  "C:\jsonfile" `
#        -ServerName    "localhost" `
#        -DatabaseName  "QLearnDB" `
#        -TargetSchema  "dbo" `
#        -TargetTable   "QLearnEvents" `
#        -BatchSize     50000
#
#  REQUIREMENTS:
#    PowerShell 5.1 or PowerShell 7+
#    Newtonsoft.Json.dll in the same folder as this script
#      → Download: https://www.nuget.org/packages/Newtonsoft.Json
#      → Or:  Install-Package Newtonsoft.Json -Destination .
# ============================================================================

[CmdletBinding()]
param(
    [string] $SourceFolder  = "C:\jsonfile",
    [string] $ServerName    = "localhost",
    [string] $DatabaseName  = "QLearnDB",
    [string] $TargetSchema  = "dbo",
    [string] $TargetTable   = "QLearnEvents",
    [int]    $BatchSize     = 50000,
    [switch] $Recurse
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Load Newtonsoft.Json
# ---------------------------------------------------------------------------
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$newtonsoftPath = Join-Path $scriptDir "Newtonsoft.Json.dll"

if (-not (Test-Path $newtonsoftPath)) {
    Write-Error @"
Newtonsoft.Json.dll not found at: $newtonsoftPath
Download it from NuGet:
  1. nuget.exe install Newtonsoft.Json -OutputDirectory .\packages
  2. Copy .\packages\Newtonsoft.Json.XX\lib\net45\Newtonsoft.Json.dll to $scriptDir
"@
}

Add-Type -Path $newtonsoftPath

# ---------------------------------------------------------------------------
# Helper: build a .NET DataTable matching the target SQL schema
# ---------------------------------------------------------------------------
function New-QLearnDataTable {
    $dt = New-Object System.Data.DataTable
    $cols = @(
        @("qlearn_file_name",                   [string]),
        @("split_file_name",                    [string]),
        @("key_id",                             [long]),
        @("value_timestamp",                    [DateTime]),
        @("value_user_id",                      [long]),
        @("value_real_user_id",                 [long]),
        @("value_course_id",                    [long]),
        @("value_quiz_id",                      [long]),
        @("value_discussion_id",                [long]),
        @("value_conversation_id",              [long]),
        @("value_assignment_id",                [long]),
        @("value_url",                          [string]),
        @("value_http_method",                  [string]),
        @("value_http_status",                  [int]),
        @("value_http_version",                 [string]),
        @("value_remote_ip",                    [string]),
        @("value_interaction_micros",           [long]),
        @("value_web_application_controller",   [string]),
        @("value_web_application_action",       [string]),
        @("value_web_application_context_type", [string]),
        @("value_web_application_context_id",   [string]),
        @("value_session_id",                   [string]),
        @("value_developer_key_id",             [long]),
        @("value_participated",                 [bool]),
        @("value_user_agent",                   [string]),
        @("meta_ts",                            [DateTime]),
        @("meta_action",                        [string])
    )
    foreach ($col in $cols) {
        $dc = New-Object System.Data.DataColumn($col[0], $col[1])
        $dc.AllowDBNull = $true
        $dt.Columns.Add($dc) | Out-Null
    }
    return $dt
}

# ---------------------------------------------------------------------------
# Helper: safe type converters
# ---------------------------------------------------------------------------
function ConvertTo-SafeLong([string]$s) {
    [long]$v = 0
    if ([long]::TryParse($s, [ref]$v)) { return $v }
    return [System.DBNull]::Value
}
function ConvertTo-SafeInt([string]$s) {
    [int]$v = 0
    if ([int]::TryParse($s, [ref]$v)) { return $v }
    return [System.DBNull]::Value
}
function ConvertTo-SafeDateTime([string]$s) {
    [DateTime]$v = [DateTime]::MinValue
    if ([DateTime]::TryParse($s, [ref]$v)) { return $v }
    return [System.DBNull]::Value
}
function ConvertTo-SafeBool([string]$s) {
    [bool]$v = $false
    if ([bool]::TryParse($s, [ref]$v)) { return $v }
    if ($s -eq "1" -or $s -eq "yes") { return $true }
    if ($s -eq "0" -or $s -eq "no")  { return $false }
    return [System.DBNull]::Value
}

# ---------------------------------------------------------------------------
# Helper: load one JSON file into SQL Server
# ---------------------------------------------------------------------------
function Invoke-LoadJsonFile {
    param(
        [string] $FilePath,
        [string] $ConnStr,
        [string] $QualifiedTable,
        [int]    $BatchSize
    )

    $fileName    = [System.IO.Path]::GetFileName($FilePath)
    $totalRows   = 0
    $batchNum    = 0
    $sw          = [System.Diagnostics.Stopwatch]::StartNew()

    Write-Host "  → Processing: $fileName" -ForegroundColor Cyan

    $dt         = New-QLearnDataTable
    $sr         = [System.IO.StreamReader]::new($FilePath)
    $reader     = [Newtonsoft.Json.JsonTextReader]::new($sr)
    $conn       = [System.Data.SqlClient.SqlConnection]::new($ConnStr)

    try {
        $conn.Open()

        $bulkCopy = New-Object System.Data.SqlClient.SqlBulkCopy($conn,
            [System.Data.SqlClient.SqlBulkCopyOptions]::TableLock -bor
            [System.Data.SqlClient.SqlBulkCopyOptions]::UseInternalTransaction,
            $null)

        $bulkCopy.DestinationTableName = $QualifiedTable
        $bulkCopy.BatchSize            = $BatchSize
        $bulkCopy.BulkCopyTimeout      = 3600

        foreach ($col in $dt.Columns) {
            $bulkCopy.ColumnMappings.Add($col.ColumnName, $col.ColumnName) | Out-Null
        }

        # Stream the JSON
        $reader.Read() | Out-Null

        while ($reader.TokenType -ne [Newtonsoft.Json.JsonToken]::None) {
            switch ($reader.TokenType) {
                ([Newtonsoft.Json.JsonToken]::StartArray)  { $reader.Read() | Out-Null; break }
                ([Newtonsoft.Json.JsonToken]::EndArray)    { $reader.Read() | Out-Null; break }

                ([Newtonsoft.Json.JsonToken]::StartObject) {
                    # Read all properties of this object
                    $row = @{
                        qlearn_file_name                   = $fileName
                        split_file_name                    = [System.DBNull]::Value
                        key_id                             = [System.DBNull]::Value
                        value_timestamp                    = [System.DBNull]::Value
                        value_user_id                      = [System.DBNull]::Value
                        value_real_user_id                 = [System.DBNull]::Value
                        value_course_id                    = [System.DBNull]::Value
                        value_quiz_id                      = [System.DBNull]::Value
                        value_discussion_id                = [System.DBNull]::Value
                        value_conversation_id              = [System.DBNull]::Value
                        value_assignment_id                = [System.DBNull]::Value
                        value_url                          = [System.DBNull]::Value
                        value_http_method                  = [System.DBNull]::Value
                        value_http_status                  = [System.DBNull]::Value
                        value_http_version                 = [System.DBNull]::Value
                        value_remote_ip                    = [System.DBNull]::Value
                        value_interaction_micros           = [System.DBNull]::Value
                        value_web_application_controller   = [System.DBNull]::Value
                        value_web_application_action       = [System.DBNull]::Value
                        value_web_application_context_type = [System.DBNull]::Value
                        value_web_application_context_id   = [System.DBNull]::Value
                        value_session_id                   = [System.DBNull]::Value
                        value_developer_key_id             = [System.DBNull]::Value
                        value_participated                 = [System.DBNull]::Value
                        value_user_agent                   = [System.DBNull]::Value
                        meta_ts                            = [System.DBNull]::Value
                        meta_action                        = [System.DBNull]::Value
                    }

                    while ($reader.Read() -and $reader.TokenType -ne [Newtonsoft.Json.JsonToken]::EndObject) {
                        if ($reader.TokenType -ne [Newtonsoft.Json.JsonToken]::PropertyName) { continue }
                        $propName = $reader.Value.ToString().ToLowerInvariant()
                        $reader.Read() | Out-Null
                        $val = if ($reader.TokenType -eq [Newtonsoft.Json.JsonToken]::Null) { $null } else { $reader.Value?.ToString() }

                        switch ($propName) {
                            "qlearn_file_name"                   { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "split_file_name"                    { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "key_id"                             { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_timestamp"                    { $row[$propName] = ConvertTo-SafeDateTime $val }
                            "value_user_id"                      { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_real_user_id"                 { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_course_id"                    { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_quiz_id"                      { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_discussion_id"                { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_conversation_id"              { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_assignment_id"                { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_url"                          { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_http_method"                  { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_http_status"                  { $row[$propName] = ConvertTo-SafeInt $val }
                            "value_http_version"                 { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_remote_ip"                    { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_interaction_micros"           { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_web_application_controller"   { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_web_application_action"       { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_web_application_context_type" { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_web_application_context_id"   { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_session_id"                   { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "value_developer_key_id"             { $row[$propName] = ConvertTo-SafeLong $val }
                            "value_participated"                 { $row[$propName] = ConvertTo-SafeBool $val }
                            "value_user_agent"                   { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                            "meta_ts"                            { $row[$propName] = ConvertTo-SafeDateTime $val }
                            "meta_action"                        { $row[$propName] = if ($val) { $val } else { [System.DBNull]::Value } }
                        }
                    }

                    # Add to DataTable
                    $dtRow = $dt.NewRow()
                    foreach ($col in $dt.Columns) { $dtRow[$col.ColumnName] = $row[$col.ColumnName] }
                    $dt.Rows.Add($dtRow) | Out-Null
                    $totalRows++

                    # Flush batch
                    if ($dt.Rows.Count -ge $BatchSize) {
                        $batchNum++
                        $bulkCopy.WriteToServer($dt)
                        $dt.Clear()
                        $rps = [math]::Round($totalRows / $sw.Elapsed.TotalSeconds, 0)
                        Write-Host "    Batch $batchNum flushed | Total rows: $($totalRows.ToString('N0')) | Rate: $rps rows/sec"
                    }
                    $reader.Read() | Out-Null
                    break
                }

                default { $reader.Read() | Out-Null; break }
            }
        }

        # Final partial batch
        if ($dt.Rows.Count -gt 0) {
            $batchNum++
            $bulkCopy.WriteToServer($dt)
            $dt.Clear()
        }

        $bulkCopy.Close()
    }
    finally {
        $reader.Close()
        $sr.Close()
        $conn.Close()
    }

    $sw.Stop()
    $elapsed = $sw.Elapsed.ToString("hh\:mm\:ss")
    Write-Host "  ✔ $fileName done: $($totalRows.ToString('N0')) rows in $elapsed" -ForegroundColor Green
    return $totalRows
}

# ===========================================================================
#  MAIN
# ===========================================================================

$connStr       = "Data Source=$ServerName;Initial Catalog=$DatabaseName;Integrated Security=SSPI;Connection Timeout=120;"
$qualTable     = "[$TargetSchema].[$TargetTable]"
$searchOption  = if ($Recurse) { [System.IO.SearchOption]::AllDirectories } else { [System.IO.SearchOption]::TopDirectoryOnly }

Write-Host ""
Write-Host "======================================================" -ForegroundColor Yellow
Write-Host "  JSON → SQL Server Bulk Loader" -ForegroundColor Yellow
Write-Host "  Source : $SourceFolder" -ForegroundColor Yellow
Write-Host "  Target : $ServerName.$DatabaseName.$qualTable" -ForegroundColor Yellow
Write-Host "  Batch  : $BatchSize rows" -ForegroundColor Yellow
Write-Host "======================================================" -ForegroundColor Yellow
Write-Host ""

$files = [System.IO.Directory]::GetFiles($SourceFolder, "*.json", $searchOption)
if ($files.Count -eq 0) {
    Write-Warning "No .json files found in $SourceFolder"
    exit 0
}

Write-Host "Found $($files.Count) JSON file(s) to process." -ForegroundColor Cyan
Write-Host ""

$grandTotal = 0
$fileCount  = 0
$grandSw    = [System.Diagnostics.Stopwatch]::StartNew()

foreach ($file in $files) {
    $fileCount++
    Write-Host "[$fileCount/$($files.Count)]" -NoNewline
    $rows = Invoke-LoadJsonFile -FilePath $file -ConnStr $connStr -QualifiedTable $qualTable -BatchSize $BatchSize
    $grandTotal += $rows
}

$grandSw.Stop()
$totalTime = $grandSw.Elapsed.ToString("hh\:mm\:ss")

Write-Host ""
Write-Host "======================================================" -ForegroundColor Green
Write-Host "  COMPLETE" -ForegroundColor Green
Write-Host "  Files    : $fileCount" -ForegroundColor Green
Write-Host "  Total rows: $($grandTotal.ToString('N0'))" -ForegroundColor Green
Write-Host "  Time     : $totalTime" -ForegroundColor Green
Write-Host "======================================================" -ForegroundColor Green
