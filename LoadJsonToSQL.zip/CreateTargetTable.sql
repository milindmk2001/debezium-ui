-- ============================================================================
--  CreateTargetTable.sql
--  Run this on your target SQL Server BEFORE executing the SSIS package.
--  Adjust database/schema names as needed.
-- ============================================================================

USE [QLearnDB];        -- ← change to your database name
GO

-- --------------------------------------------------------------------------
-- 1.  Create target table
-- --------------------------------------------------------------------------
IF OBJECT_ID('[dbo].[QLearnEvents]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[QLearnEvents]
    (
        -- Surrogate key — auto-populated, no SSIS mapping needed
        [load_id]                            BIGINT          IDENTITY(1,1) NOT NULL,

        -- Source file tracking
        [qlearn_file_name]                   NVARCHAR(500)   NULL,
        [split_file_name]                    NVARCHAR(500)   NULL,

        -- Business keys
        [key_id]                             BIGINT          NULL,

        -- Timestamps
        [value_timestamp]                    DATETIME2(7)    NULL,

        -- User / actor IDs
        [value_user_id]                      BIGINT          NULL,
        [value_real_user_id]                 BIGINT          NULL,

        -- Context IDs (nullable — most events populate only a subset)
        [value_course_id]                    BIGINT          NULL,
        [value_quiz_id]                      BIGINT          NULL,
        [value_discussion_id]                BIGINT          NULL,
        [value_conversation_id]              BIGINT          NULL,
        [value_assignment_id]               BIGINT          NULL,

        -- HTTP request fields
        [value_url]                          NVARCHAR(2000)  NULL,
        [value_http_method]                  NVARCHAR(20)    NULL,
        [value_http_status]                  SMALLINT        NULL,
        [value_http_version]                 NVARCHAR(20)    NULL,
        [value_remote_ip]                    NVARCHAR(50)    NULL,
        [value_interaction_micros]           BIGINT          NULL,

        -- Web application context
        [value_web_application_controller]   NVARCHAR(200)   NULL,
        [value_web_application_action]       NVARCHAR(200)   NULL,
        [value_web_application_context_type] NVARCHAR(200)   NULL,
        [value_web_application_context_id]   NVARCHAR(100)   NULL,

        -- Session / auth
        [value_session_id]                   NVARCHAR(500)   NULL,
        [value_developer_key_id]             BIGINT          NULL,
        [value_participated]                 BIT             NULL,
        [value_user_agent]                   NVARCHAR(MAX)   NULL,

        -- Metadata
        [meta_ts]                            DATETIME2(7)    NULL,
        [meta_action]                        NVARCHAR(100)   NULL,

        -- Load audit
        [load_ts]                            DATETIME2(7)    NOT NULL
                                                 CONSTRAINT [DF_QLearnEvents_load_ts]
                                                 DEFAULT SYSUTCDATETIME(),

        CONSTRAINT [PK_QLearnEvents] PRIMARY KEY CLUSTERED ([load_id] ASC)
            WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF,
                  FILLFACTOR = 90, DATA_COMPRESSION = PAGE)
    )
    ON [PRIMARY]
    TEXTIMAGE_ON [PRIMARY];

    PRINT 'Table [dbo].[QLearnEvents] created.';
END
ELSE
    PRINT 'Table [dbo].[QLearnEvents] already exists — skipping CREATE.';
GO

-- --------------------------------------------------------------------------
-- 2.  Non-clustered indexes for common query patterns
--     Add / remove based on your actual query workload.
--     NOTE: Drop these before the initial bulk load, recreate after for speed.
-- --------------------------------------------------------------------------

-- Drop-and-recreate helper pattern
IF EXISTS (SELECT 1 FROM sys.indexes
           WHERE object_id = OBJECT_ID('[dbo].[QLearnEvents]')
             AND name = 'IX_QLearnEvents_value_timestamp')
    DROP INDEX [IX_QLearnEvents_value_timestamp] ON [dbo].[QLearnEvents];

CREATE NONCLUSTERED INDEX [IX_QLearnEvents_value_timestamp]
    ON [dbo].[QLearnEvents] ([value_timestamp] ASC)
    INCLUDE ([value_user_id], [value_course_id], [value_http_status])
    WITH (DATA_COMPRESSION = PAGE, FILLFACTOR = 90);
GO

IF EXISTS (SELECT 1 FROM sys.indexes
           WHERE object_id = OBJECT_ID('[dbo].[QLearnEvents]')
             AND name = 'IX_QLearnEvents_value_user_id')
    DROP INDEX [IX_QLearnEvents_value_user_id] ON [dbo].[QLearnEvents];

CREATE NONCLUSTERED INDEX [IX_QLearnEvents_value_user_id]
    ON [dbo].[QLearnEvents] ([value_user_id] ASC)
    INCLUDE ([value_timestamp], [value_course_id], [value_http_status])
    WITH (DATA_COMPRESSION = PAGE, FILLFACTOR = 90);
GO

IF EXISTS (SELECT 1 FROM sys.indexes
           WHERE object_id = OBJECT_ID('[dbo].[QLearnEvents]')
             AND name = 'IX_QLearnEvents_value_course_id')
    DROP INDEX [IX_QLearnEvents_value_course_id] ON [dbo].[QLearnEvents];

CREATE NONCLUSTERED INDEX [IX_QLearnEvents_value_course_id]
    ON [dbo].[QLearnEvents] ([value_course_id] ASC)
    WITH (DATA_COMPRESSION = PAGE, FILLFACTOR = 90);
GO

IF EXISTS (SELECT 1 FROM sys.indexes
           WHERE object_id = OBJECT_ID('[dbo].[QLearnEvents]')
             AND name = 'IX_QLearnEvents_qlearn_file_name')
    DROP INDEX [IX_QLearnEvents_qlearn_file_name] ON [dbo].[QLearnEvents];

CREATE NONCLUSTERED INDEX [IX_QLearnEvents_qlearn_file_name]
    ON [dbo].[QLearnEvents] ([qlearn_file_name] ASC, [split_file_name] ASC)
    WITH (DATA_COMPRESSION = PAGE, FILLFACTOR = 90);
GO

PRINT 'Indexes created/refreshed.';
GO

-- --------------------------------------------------------------------------
-- 3.  Optional: staging table for incremental / upsert scenarios
--     Same schema, no PK — used as a BULK INSERT target before merging
-- --------------------------------------------------------------------------
IF OBJECT_ID('[dbo].[QLearnEvents_Staging]', 'U') IS NULL
BEGIN
    SELECT TOP 0 *
    INTO [dbo].[QLearnEvents_Staging]
    FROM [dbo].[QLearnEvents];

    -- Remove IDENTITY property — staging doesn't need it
    ALTER TABLE [dbo].[QLearnEvents_Staging]
        DROP COLUMN [load_id];

    PRINT 'Staging table [dbo].[QLearnEvents_Staging] created.';
END
GO

-- --------------------------------------------------------------------------
-- 4.  Grant minimal permissions to the SSIS service account
--     Replace ##SSISServiceAccount## with the actual account name.
-- --------------------------------------------------------------------------
-- GRANT INSERT, SELECT ON [dbo].[QLearnEvents]          TO [##SSISServiceAccount##];
-- GRANT INSERT, SELECT ON [dbo].[QLearnEvents_Staging]  TO [##SSISServiceAccount##];
-- GO

-- --------------------------------------------------------------------------
-- 5.  Verify
-- --------------------------------------------------------------------------
SELECT
    c.column_id,
    c.name            AS column_name,
    t.name            AS data_type,
    c.max_length,
    c.is_nullable
FROM sys.columns c
JOIN sys.types   t ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID('[dbo].[QLearnEvents]')
ORDER BY c.column_id;
GO
