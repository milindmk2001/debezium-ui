# SSIS JSON Loader — Setup Instructions

## Files in This Package

| File | Purpose |
|---|---|
| `LoadJsonToSQL.dtsx` | SSIS package (open in SSDT) |
| `ScriptTask_JsonLoader.cs` | C# code — paste into the SSIS Script Task editor |
| `CreateTargetTable.sql` | Creates the target table + indexes in SQL Server |
| `PackageConfig.dtsConfig` | SSIS configuration file (environment overrides) |
| `LoadJson_Standalone.ps1` | **Alternative**: run without SSIS at all |

---

## Prerequisites

| Component | Version |
|---|---|
| SQL Server | 2017, 2019, or 2022 |
| SSDT (SQL Server Data Tools) | Visual Studio 2019 or 2022 |
| Integration Services | Same major version as SQL Server |
| .NET Framework | 4.7.2+ |
| Newtonsoft.Json NuGet | 13.0+ |

---

## Step 1 — Create the Target Table

1. Open **SQL Server Management Studio (SSMS)**.
2. Connect to `localhost` (or your target server) with **Windows Authentication**.
3. Open `CreateTargetTable.sql`.
4. Change `USE [QLearnDB]` at the top to your actual database name.
5. Execute the script (F5).

> **Performance tip for 100M+ rows**: The script creates non-clustered indexes
> after the table. For the initial bulk load, consider dropping those indexes first,
> bulk-loading all files, then recreating them. This can be 3–5× faster.

```sql
-- Drop indexes before bulk load
DROP INDEX IF EXISTS [IX_QLearnEvents_value_timestamp]  ON [dbo].[QLearnEvents];
DROP INDEX IF EXISTS [IX_QLearnEvents_value_user_id]    ON [dbo].[QLearnEvents];
DROP INDEX IF EXISTS [IX_QLearnEvents_value_course_id]  ON [dbo].[QLearnEvents];
DROP INDEX IF EXISTS [IX_QLearnEvents_qlearn_file_name] ON [dbo].[QLearnEvents];

-- ... run SSIS load here ...

-- Then recreate from CreateTargetTable.sql section 2
```

---

## Step 2 — Copy the SSIS Package

Place all four files in the same folder, for example:

```
C:\SSIS\LoadJsonToSQL\
    LoadJsonToSQL.dtsx
    ScriptTask_JsonLoader.cs
    PackageConfig.dtsConfig
    LoadJson_Standalone.ps1
```

---

## Step 3 — Open the Package in SSDT

1. Open **Visual Studio** with SSIS tooling installed.
2. File → Open → File → select `LoadJsonToSQL.dtsx`.
3. The package opens. You will see one container: **"FELC - Iterate JSON Files"**
   containing one task: **"SCR - Load JSON File to SQL"**.

---

## Step 4 — Add the Script Task Code

> This is the most critical step. The `.dtsx` file carries the package structure
> but the C# code must be added via SSDT because SSIS stores script projects as
> compiled binaries inside the package.

1. Double-click **"SCR - Load JSON File to SQL"**.
2. In the Script Task Editor, verify:
   - **ScriptLanguage**: Microsoft Visual C# 2019
   - **ReadOnlyVariables**: `$Package::ServerName, $Package::DatabaseName, $Package::TargetSchema, $Package::TargetTable, $Package::BatchSize`
   - **ReadWriteVariables**: `User::CurrentFilePath, User::FilesProcessed, User::TotalRowsLoaded`
3. Click **"Edit Script…"**  — Visual Studio Tools for Applications (VSTA) opens.
4. **Add Newtonsoft.Json**:
   - In VSTA: Tools → NuGet Package Manager → Manage NuGet Packages for Solution
   - Search for `Newtonsoft.Json` → Install (latest stable)
5. In VSTA, open `ScriptMain.cs`.
6. Delete everything **inside** the `ScriptMain` class body (keep the class declaration).
7. Open `ScriptTask_JsonLoader.cs` from this package.
8. Copy **everything from** `public void Main()` **down to the end of the file**.
9. Paste it inside the `ScriptMain` class in VSTA.
10. Build → Build Solution (Ctrl+Shift+B).  Fix any compile errors.
11. Close VSTA (File → Exit).
12. Click **OK** to close the Script Task Editor.
13. Save the package (Ctrl+S).

---

## Step 5 — Configure Package Parameters

The package has six parameters visible in the **Parameters** tab:

| Parameter | Default | Description |
|---|---|---|
| `SourceFolder` | `C:\jsonfile` | Folder containing `.json` files |
| `ServerName` | `localhost` | SQL Server name or IP |
| `DatabaseName` | `QLearnDB` | Target database |
| `TargetSchema` | `dbo` | Target schema |
| `TargetTable` | `QLearnEvents` | Target table |
| `BatchSize` | `50000` | Rows per `SqlBulkCopy` round-trip |

**To change defaults in SSDT**: Click the **Parameters** tab at the bottom of the
package design surface and edit the `Value` column.

**To override at runtime** (preferred for multiple environments), see Step 6.

---

## Step 6 — Configure the .dtsConfig File

Edit `PackageConfig.dtsConfig` in any text editor.  Change the `<ConfiguredValue>`
elements to match your environment:

```xml
<!-- Example: production server -->
<Configuration ...Path="\Package.Parameters[ServerName]...">
    <ConfiguredValue>PRODSERVER01\INST1</ConfiguredValue>
</Configuration>

<Configuration ...Path="\Package.Parameters[DatabaseName]...">
    <ConfiguredValue>QLearnProd</ConfiguredValue>
</Configuration>

<Configuration ...Path="\Package.Parameters[SourceFolder]...">
    <ConfiguredValue>D:\data\json\input</ConfiguredValue>
</Configuration>
```

Attach the config file to the package:

1. In SSDT: SSIS menu → **Package Configurations**.
2. Check **"Enable Package Configurations"**.
3. Click **Add** → Type = **XML Configuration File** → browse to `PackageConfig.dtsConfig`.
4. Select all properties to override → Finish → Close.

---

## Step 7 — Run the Package

### Option A — Run from SSDT (debug / dev)

Press **F5** or click the green Start button.  Watch the progress output and any
errors in the Progress / Execution Results tabs.

### Option B — Run from command line (dtexec)

```cmd
dtexec /F "C:\SSIS\LoadJsonToSQL\LoadJsonToSQL.dtsx" ^
       /ConfigFile "C:\SSIS\LoadJsonToSQL\PackageConfig.dtsConfig"
```

Override individual parameters inline:

```cmd
dtexec /F "C:\SSIS\LoadJsonToSQL\LoadJsonToSQL.dtsx" ^
       /SET \Package.Parameters[SourceFolder].Value;"D:\data\json" ^
       /SET \Package.Parameters[ServerName].Value;"MYSERVER" ^
       /SET \Package.Parameters[DatabaseName].Value;"QLearnProd"
```

### Option C — Deploy to SSIS Catalog (SSISDB) and run via SQL Agent

1. Right-click the project in Solution Explorer → Deploy.
2. Target = SSIS Catalog on your SQL Server.
3. After deployment, create an **Environment** in SSISDB with variables matching
   the six package parameters.
4. Create a **SQL Agent Job** → Step Type = SQL Server Integration Services Package
   → point to the deployed package → map the environment.

---

## Alternative: Run Without SSIS (PowerShell)

If you don't have SSIS installed, use `LoadJson_Standalone.ps1`:

**Requirements**: Newtonsoft.Json.dll in the same folder as the script.

```powershell
# Download Newtonsoft.Json.dll (run once)
Install-Package Newtonsoft.Json -Destination "C:\SSIS\LoadJsonToSQL" -SkipDependencies

# Run the loader
.\LoadJson_Standalone.ps1 `
    -SourceFolder  "C:\jsonfile" `
    -ServerName    "localhost" `
    -DatabaseName  "QLearnDB" `
    -TargetSchema  "dbo" `
    -TargetTable   "QLearnEvents" `
    -BatchSize     50000
```

---

## Performance Tuning for 100M+ Rows

### SQL Server settings (apply before load)

```sql
-- Minimal logging (Simple or Bulk-Logged recovery model during load)
ALTER DATABASE [QLearnDB] SET RECOVERY BULK_LOGGED;

-- Increase fill factor on target table to reduce page splits
-- (already set in CreateTargetTable.sql)

-- After load: switch back to Full if required
ALTER DATABASE [QLearnDB] SET RECOVERY FULL;
```

### SSIS / Script Task settings

| Parameter | Guideline |
|---|---|
| `BatchSize` | 50,000–100,000 rows. Larger = fewer round-trips but more memory. |
| TempDB | Put tempdb data files on fast NVMe. SqlBulkCopy uses it heavily. |
| Max Memory | Give SQL Server at least 8 GB. Buffer pool absorbs the bulk inserts. |
| Parallelism | For multiple JSON files, consider running multiple SSIS instances in parallel on different file subsets. |

### Estimated throughput

On a modern server (NVMe, 16-core, SQL Server 2019):

| Scenario | Rows/sec |
|---|---|
| Single SSIS process, 1 file | 200,000–500,000 |
| 4 parallel SSIS processes | 600,000–1,500,000 |
| PowerShell standalone | 150,000–350,000 |

100 million rows ÷ 300,000 rows/sec ≈ **~6 minutes per process** under ideal conditions.

---

## Troubleshooting

| Symptom | Cause / Fix |
|---|---|
| `DTS_E_SCRIPTROJECT` error on open | Script code not yet added — follow Step 4 |
| `Cannot find column 'xxx'` in SqlBulkCopy | JSON property name doesn't match column — check mapping in `ReadJsonObject()` |
| `Timeout expired` | Increase `BulkCopyTimeout` in the C# code (currently 3600 s) |
| `Invalid object name 'dbo.QLearnEvents'` | Run `CreateTargetTable.sql` first |
| `Login failed` | Confirm the SSIS service account has SQL access; verify Windows Auth |
| JSON parse error | Check that files are valid JSON (array `[{...}]` or newline-delimited `{...}\n{...}`) |
| Memory pressure | Reduce `BatchSize` to 10,000–25,000 |

---

## Folder Structure Reference

```
C:\SSIS\LoadJsonToSQL\
│
├── LoadJsonToSQL.dtsx           ← SSIS package
├── ScriptTask_JsonLoader.cs     ← C# code (paste into Script Task)
├── PackageConfig.dtsConfig      ← Environment config
├── LoadJson_Standalone.ps1      ← PowerShell alternative
├── CreateTargetTable.sql        ← SQL DDL
├── SETUP_INSTRUCTIONS.md        ← This file
└── Newtonsoft.Json.dll          ← Place here if not using NuGet
```

---

*Generated for SQL Server 2019 / SSIS 15.x / SSDT for VS 2019–2022*
