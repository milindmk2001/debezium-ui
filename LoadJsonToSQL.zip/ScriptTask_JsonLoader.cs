// ============================================================================
//  ScriptTask_JsonLoader.cs
//  SSIS Script Task — streams large JSON files into SQL Server via SqlBulkCopy
//
//  Dependencies (add via SSDT NuGet Package Manager inside the VSTA editor):
//    Newtonsoft.Json  >= 13.0.0
//
//  HOW TO USE IN SSIS SSDT:
//    1. Double-click the Script Task "SCR - Load JSON File to SQL"
//    2. Set ScriptLanguage = Microsoft Visual C# 2019
//    3. Confirm ReadOnlyVariables and ReadWriteVariables match the package
//    4. Click "Edit Script…" — VSTA opens
//    5. In VSTA: Tools → NuGet Package Manager → Install Newtonsoft.Json
//    6. Replace everything INSIDE the ScriptMain class with the code below
//    7. Save + close VSTA
// ============================================================================

#region Namespaces
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using Microsoft.SqlServer.Dts.Runtime;
using Newtonsoft.Json;
#endregion

// ---- SSIS auto-generates the outer namespace / class declaration ----------
// Replace the BODY of the ScriptMain class with everything below this line:

/// <summary>
/// Streams one JSON file and bulk-inserts rows into the target SQL table.
/// Designed for files with 100 M+ rows: memory footprint stays flat because
/// JsonTextReader never loads the entire document into RAM.
/// </summary>
public void Main()
{
    // -----------------------------------------------------------------------
    // 1.  Read package parameters / variables
    // -----------------------------------------------------------------------
    string filePath    = Dts.Variables["User::CurrentFilePath"].Value.ToString();
    string serverName  = Dts.Variables["$Package::ServerName"].Value.ToString();
    string dbName      = Dts.Variables["$Package::DatabaseName"].Value.ToString();
    string schema      = Dts.Variables["$Package::TargetSchema"].Value.ToString();
    string table       = Dts.Variables["$Package::TargetTable"].Value.ToString();
    int    batchSize   = Convert.ToInt32(Dts.Variables["$Package::BatchSize"].Value);

    string qualifiedTable = $"[{schema}].[{table}]";
    string fileName   = Path.GetFileName(filePath);

    // Build a Windows-Auth connection string (matches package connection manager)
    string connStr = $"Data Source={serverName};" +
                     $"Initial Catalog={dbName};" +
                      "Integrated Security=SSPI;" +
                      "MultipleActiveResultSets=False;" +
                      "Connection Timeout=120;";

    Dts.Events.FireInformation(0, "SCR - Load JSON File",
        $"Starting file: {fileName}", string.Empty, 0, ref _fireAgain);

    try
    {
        // -------------------------------------------------------------------
        // 2.  Build the DataTable schema (matches target SQL table exactly)
        // -------------------------------------------------------------------
        DataTable dt = BuildDataTable();

        long totalRows = 0;
        long batchNumber = 0;

        using (var sr     = new StreamReader(filePath))
        using (var reader = new JsonTextReader(sr))
        using (var conn   = new SqlConnection(connStr))
        {
            conn.Open();

            // Configure SqlBulkCopy for maximum throughput
            using (var bulkCopy = new SqlBulkCopy(conn,
                       SqlBulkCopyOptions.TableLock |
                       SqlBulkCopyOptions.FireTriggers |
                       SqlBulkCopyOptions.UseInternalTransaction,
                       null))
            {
                bulkCopy.DestinationTableName = qualifiedTable;
                bulkCopy.BatchSize            = batchSize;
                bulkCopy.BulkCopyTimeout      = 3600; // 1 hour per batch

                // Map every DataTable column to the matching SQL column
                foreach (DataColumn col in dt.Columns)
                    bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);

                // -----------------------------------------------------------
                // 3.  Stream the JSON — two supported layouts:
                //       a) Array of objects:  [ {...}, {...}, ... ]
                //       b) Newline-delimited:  {...}\n{...}\n...
                // -----------------------------------------------------------
                reader.Read(); // position on first token

                while (reader.TokenType != JsonToken.None)
                {
                    if (reader.TokenType == JsonToken.StartArray)
                    {
                        reader.Read(); // move inside array
                        continue;
                    }
                    if (reader.TokenType == JsonToken.EndArray)
                    {
                        reader.Read();
                        continue;
                    }
                    if (reader.TokenType == JsonToken.StartObject)
                    {
                        // Deserialise single object from stream
                        var obj = ReadJsonObject(reader, fileName);
                        dt.Rows.Add(obj);
                        totalRows++;

                        // Flush batch when full
                        if (dt.Rows.Count >= batchSize)
                        {
                            batchNumber++;
                            bulkCopy.WriteToServer(dt);
                            dt.Clear();

                            Dts.Events.FireInformation(0, "SCR - Load JSON File",
                                $"{fileName}: batch {batchNumber} written " +
                                $"(~{totalRows:N0} rows so far)", string.Empty, 0, ref _fireAgain);
                        }
                        reader.Read(); // next token after the object
                    }
                    else
                    {
                        reader.Read(); // skip unexpected tokens
                    }
                }

                // Flush remaining rows in the last partial batch
                if (dt.Rows.Count > 0)
                {
                    batchNumber++;
                    bulkCopy.WriteToServer(dt);
                    dt.Clear();
                }
            } // end SqlBulkCopy
        }   // end stream + connection

        Dts.Events.FireInformation(0, "SCR - Load JSON File",
            $"Finished {fileName}: {totalRows:N0} rows in {batchNumber} batches.",
            string.Empty, 0, ref _fireAgain);

        // Accumulate counters in package variables
        Dts.Variables["User::FilesProcessed"].Value =
            Convert.ToInt32(Dts.Variables["User::FilesProcessed"].Value) + 1;
        Dts.Variables["User::TotalRowsLoaded"].Value =
            Convert.ToInt32(Dts.Variables["User::TotalRowsLoaded"].Value) + (int)totalRows;

        Dts.TaskResult = (int)ScriptResults.Success;
    }
    catch (Exception ex)
    {
        Dts.Events.FireError(0, "SCR - Load JSON File",
            $"Error processing {fileName}: {ex.Message}\n{ex.StackTrace}",
            string.Empty, 0);
        Dts.TaskResult = (int)ScriptResults.Failure;
    }
}

// ============================================================================
//  Helper — read a single JSON object from the streaming reader
//  Returns a DataRow's object[] array aligned to BuildDataTable() columns
// ============================================================================
private object[] ReadJsonObject(JsonTextReader reader, string fileName)
{
    // Defaults for nullable / optional fields
    object qlearn_file_name                  = fileName;
    object split_file_name                   = DBNull.Value;
    object key_id                            = DBNull.Value;
    object value_timestamp                   = DBNull.Value;
    object value_user_id                     = DBNull.Value;
    object value_real_user_id               = DBNull.Value;
    object value_course_id                  = DBNull.Value;
    object value_quiz_id                    = DBNull.Value;
    object value_discussion_id              = DBNull.Value;
    object value_conversation_id            = DBNull.Value;
    object value_assignment_id              = DBNull.Value;
    object value_url                        = DBNull.Value;
    object value_http_method                = DBNull.Value;
    object value_http_status                = DBNull.Value;
    object value_http_version               = DBNull.Value;
    object value_remote_ip                  = DBNull.Value;
    object value_interaction_micros         = DBNull.Value;
    object value_web_application_controller = DBNull.Value;
    object value_web_application_action     = DBNull.Value;
    object value_web_application_context_type = DBNull.Value;
    object value_web_application_context_id = DBNull.Value;
    object value_session_id                 = DBNull.Value;
    object value_developer_key_id          = DBNull.Value;
    object value_participated               = DBNull.Value;
    object value_user_agent                 = DBNull.Value;
    object meta_ts                          = DBNull.Value;
    object meta_action                      = DBNull.Value;

    // Walk all properties of this JSON object
    while (reader.Read() && reader.TokenType != JsonToken.EndObject)
    {
        if (reader.TokenType != JsonToken.PropertyName) continue;

        string propName = reader.Value?.ToString() ?? string.Empty;
        reader.Read(); // move to value

        string val = reader.TokenType == JsonToken.Null
                     ? null
                     : reader.Value?.ToString();

        switch (propName.ToLowerInvariant())
        {
            case "qlearn_file_name":                   qlearn_file_name = val ?? (object)DBNull.Value; break;
            case "split_file_name":                    split_file_name  = val ?? (object)DBNull.Value; break;
            case "key_id":                             key_id           = TryParseLong(val); break;
            case "value_timestamp":                    value_timestamp  = TryParseDateTime(val); break;
            case "value_user_id":                      value_user_id    = TryParseLong(val); break;
            case "value_real_user_id":                 value_real_user_id = TryParseLong(val); break;
            case "value_course_id":                    value_course_id  = TryParseLong(val); break;
            case "value_quiz_id":                      value_quiz_id    = TryParseLong(val); break;
            case "value_discussion_id":                value_discussion_id = TryParseLong(val); break;
            case "value_conversation_id":              value_conversation_id = TryParseLong(val); break;
            case "value_assignment_id":                value_assignment_id = TryParseLong(val); break;
            case "value_url":                          value_url        = val ?? (object)DBNull.Value; break;
            case "value_http_method":                  value_http_method = val ?? (object)DBNull.Value; break;
            case "value_http_status":                  value_http_status = TryParseInt(val); break;
            case "value_http_version":                 value_http_version = val ?? (object)DBNull.Value; break;
            case "value_remote_ip":                    value_remote_ip  = val ?? (object)DBNull.Value; break;
            case "value_interaction_micros":           value_interaction_micros = TryParseLong(val); break;
            case "value_web_application_controller":   value_web_application_controller = val ?? (object)DBNull.Value; break;
            case "value_web_application_action":       value_web_application_action = val ?? (object)DBNull.Value; break;
            case "value_web_application_context_type": value_web_application_context_type = val ?? (object)DBNull.Value; break;
            case "value_web_application_context_id":   value_web_application_context_id = val ?? (object)DBNull.Value; break;
            case "value_session_id":                   value_session_id = val ?? (object)DBNull.Value; break;
            case "value_developer_key_id":             value_developer_key_id = TryParseLong(val); break;
            case "value_participated":                 value_participated = TryParseBool(val); break;
            case "value_user_agent":                   value_user_agent = val ?? (object)DBNull.Value; break;
            case "meta_ts":                            meta_ts      = TryParseDateTime(val); break;
            case "meta_action":                        meta_action  = val ?? (object)DBNull.Value; break;
            // Ignore unrecognised properties
        }
    }

    return new object[]
    {
        qlearn_file_name,
        split_file_name,
        key_id,
        value_timestamp,
        value_user_id,
        value_real_user_id,
        value_course_id,
        value_quiz_id,
        value_discussion_id,
        value_conversation_id,
        value_assignment_id,
        value_url,
        value_http_method,
        value_http_status,
        value_http_version,
        value_remote_ip,
        value_interaction_micros,
        value_web_application_controller,
        value_web_application_action,
        value_web_application_context_type,
        value_web_application_context_id,
        value_session_id,
        value_developer_key_id,
        value_participated,
        value_user_agent,
        meta_ts,
        meta_action
    };
}

// ============================================================================
//  Build in-memory DataTable — column order matches SQL target table exactly
// ============================================================================
private DataTable BuildDataTable()
{
    var dt = new DataTable();
    dt.Columns.Add("qlearn_file_name",                   typeof(string));
    dt.Columns.Add("split_file_name",                    typeof(string));
    dt.Columns.Add("key_id",                             typeof(long));
    dt.Columns.Add("value_timestamp",                    typeof(DateTime));
    dt.Columns.Add("value_user_id",                      typeof(long));
    dt.Columns.Add("value_real_user_id",                 typeof(long));
    dt.Columns.Add("value_course_id",                    typeof(long));
    dt.Columns.Add("value_quiz_id",                      typeof(long));
    dt.Columns.Add("value_discussion_id",                typeof(long));
    dt.Columns.Add("value_conversation_id",              typeof(long));
    dt.Columns.Add("value_assignment_id",                typeof(long));
    dt.Columns.Add("value_url",                          typeof(string));
    dt.Columns.Add("value_http_method",                  typeof(string));
    dt.Columns.Add("value_http_status",                  typeof(int));
    dt.Columns.Add("value_http_version",                 typeof(string));
    dt.Columns.Add("value_remote_ip",                    typeof(string));
    dt.Columns.Add("value_interaction_micros",           typeof(long));
    dt.Columns.Add("value_web_application_controller",   typeof(string));
    dt.Columns.Add("value_web_application_action",       typeof(string));
    dt.Columns.Add("value_web_application_context_type", typeof(string));
    dt.Columns.Add("value_web_application_context_id",   typeof(string));
    dt.Columns.Add("value_session_id",                   typeof(string));
    dt.Columns.Add("value_developer_key_id",             typeof(long));
    dt.Columns.Add("value_participated",                 typeof(bool));
    dt.Columns.Add("value_user_agent",                   typeof(string));
    dt.Columns.Add("meta_ts",                            typeof(DateTime));
    dt.Columns.Add("meta_action",                        typeof(string));
    return dt;
}

// ============================================================================
//  Parsing helpers (all return DBNull.Value on parse failure)
// ============================================================================
private bool _fireAgain = true;

private static object TryParseLong(string s)
{
    if (string.IsNullOrWhiteSpace(s)) return DBNull.Value;
    return long.TryParse(s, out long v) ? (object)v : DBNull.Value;
}

private static object TryParseInt(string s)
{
    if (string.IsNullOrWhiteSpace(s)) return DBNull.Value;
    return int.TryParse(s, out int v) ? (object)v : DBNull.Value;
}

private static object TryParseDateTime(string s)
{
    if (string.IsNullOrWhiteSpace(s)) return DBNull.Value;
    return DateTime.TryParse(s, null,
        System.Globalization.DateTimeStyles.RoundtripKind,
        out DateTime v) ? (object)v : DBNull.Value;
}

private static object TryParseBool(string s)
{
    if (string.IsNullOrWhiteSpace(s)) return DBNull.Value;
    if (bool.TryParse(s, out bool b)) return b;
    if (s == "1" || s.ToLower() == "yes") return true;
    if (s == "0" || s.ToLower() == "no")  return false;
    return DBNull.Value;
}
